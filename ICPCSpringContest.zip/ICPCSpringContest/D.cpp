#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<math.h>
#include <iomanip>
using namespace std;

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	long int a;
	long int b;

	cin >> a >> b;

	long int MAX = max(a, b);
	vector<long int> isprime(MAX+1);

	for (int i=2; i <= MAX; ++i) {
		isprime[i] = 1;
	}


	set<long long> first;
	set<long long> second;

	for (long int i = 2; i <= MAX; ++i) {
		if (!isprime[i]) continue;
		for (long long j = (long long)i*i; j <= MAX; j += i) {
			isprime[j] = 0;
		}
		if (a >= i && a%i == 0) {
			first.insert(i);
		}
		if (b >= i && b%i == 0) {
			second.insert(i);
		}
	}

	vector<long long> v1(MAX);
	vector<long long>::iterator it = set_intersection(first.begin(), first.end(), second.begin(), second.end(), v1.begin());

	vector<long long> v2(MAX);
	vector<long long>::iterator it2 = set_union(first.begin(), first.end(), second.begin(), second.end(), v2.begin());

	cout << fixed << setprecision(4) << (long double)(it - v1.begin()) / (it2 - v2.begin()) << endl;

	cout.flush();

	return 0;
}