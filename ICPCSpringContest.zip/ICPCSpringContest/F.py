from math import *

n = float(input())

under = 144 - (24)*(8-n)
p2 = sqrt(under)/12
A = floor(1+p2)
B = floor(1-p2)

if (A > 0):
    print(A)
elif (B>0):
    print(B)
# else:
    # print("OH NO")