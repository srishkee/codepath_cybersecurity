#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<map>
#include<set>
#include<math.h>
using namespace std;

int main(int argc, char const *argv[])
{

	ios::sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	long int n;
	long int low;
	long int high;
	cin >> n >> low >> high;

	map<long int, long int> hits;

	//for (int i = low; i <= high; ++i) {
	//	hits[i] = 0;
	//}

	long int min = 1000000000;
	int max = -1;
	for (long int i = 0; i < n; ++i) {
		long int a;
		long int b;
		cin >> a >> b;

		if (a < low) {
			a = low;
		}
		if (b > high) {
			b = high;
		}

		for (long int j = a; j <= b; ++j) {
			hits[j]++;
			// if()
		}
	}

	cout << endl;
	map<long int, long int>::iterator it;
	for (it = hits.begin(); it != hits.end(); ++it) {
		//cout << it->first << " " << it->second << endl;
		if (it->second < min) {
			min = it->second;
		}
	}
	cout << min << endl;
	cout.flush();

	return 0;
}