#include <iostream>
#include <string>
#include <set>
#include <map>
#include <vector>

using namespace std;

int main()
{
	int words, dicts;
	cin >> words >> dicts;

	map<string, set<string>> MAP;

	vector<string> message;

	for (int i = 0; i < words; i++)
	{
		string s;
		cin >> s;
		message.push_back(s);
	}

	for (int i = 0; i < dicts; i++)
	{
		int size;
		cin >> size;
	
		for (int j = 0; j < size; j++)
		{
			string s, e;
			cin >> s >> e;
			MAP[s].insert(e);
		}
	}

	long long count = 1;
	long long m = 1000000007;

	for (int i = 0; i < words; i++)
	{
		count = (count* (long long) MAP[message[i]].size()) % m;
	}
	
	cout << count << endl;

	return 0;
}