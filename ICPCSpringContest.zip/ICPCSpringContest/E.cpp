#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<map>
#include<set>
#include<math.h>
using namespace std;

int main(int argc, char const *argv[])
{
	map<string, set<string>> m;
	long long int N = 0, K = 0;
	cin >> N >> K;

	std::vector<string> message(N);

	for (long long int i = 0; i < N; ++i)
	{
		cin >> message.at(i);
	}

	for (long long int i = 0; i < K; ++i)
	{
		long long int x = 0;
		cin >> x;
		for (long long int j = 0; j < x; ++j)
		{
			string s1 = "";
			string s2 = "";
			cin >> s1 >> s2;
			// m.insert(make_pair())
			m[s1].insert(s2);
		}
	}

	long long int ctr = 1;
	long long int tmp = 1000000007; 
	for (long long int i = 0; i < message.size(); ++i)
	{
		ctr *= ((m[message.at(i)].size()) % tmp);
	}

	cout << ctr % (tmp) << endl;
	return 0;
}