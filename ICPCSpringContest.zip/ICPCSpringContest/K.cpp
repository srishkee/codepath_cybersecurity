#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<map>
#include<set>
#include<math.h>
using namespace std;

struct Node
{
	Node() : color(-1), x(-1), y(-1), z(-1) {};
	Node(long long int x, long long int y, long long int z) : color(-1), x(x), y(y), z(z) {};
	~Node() {};
	long long int color;
	long long int x, y, z;
	// string name;
	// vector<Node*> connections;
};

int main(int argc, char const *argv[])
{
	long long int n = 0;
	long long int k = 0;
	cin >> n >> k;

	std::vector<Node*> v;
	for (long long int i = 0; i < n; ++i)
	{
		long long int x = 0, y = 0, z = 0;
		cin >> x >> y >> z;
		Node* n = new Node(x, y, z);
		v.push_back(n);
	}

	queue<Node*> q;

	long long int ctr = 0;
	for (auto it : v)
	{
		float dist = sqrt((it->x*it->x) + (it->y*it->y) + (it->z*it->z));
		if (sqrt((it->x*it->x) + (it->y*it->y) + (it->z*it->z)) <= k)
		{
			it->color = 1;
			q.push(it);
			ctr++;
		}
	}

	while (!q.empty())
	{
		Node* n = q.front();
		q.pop();
		for (auto it : v)
		{
			if (it->color == -1)
			{
				float dist = sqrt(((it->x - n->x)*(it->x - n->x)) + ((it->y - n->y)*(it->y - n->y)) + (it->z - n->z)*(it->z - n->z)); 
				if (sqrt(((it->x - n->x)*(it->x - n->x)) + ((it->y - n->y)*(it->y - n->y)) + (it->z - n->z)*(it->z - n->z)) <= k)
				{
					it->color = 1;
					q.push(it);
					ctr++;
				}
			}
		}
	}

	cout << ctr << endl;

		return 0;
}