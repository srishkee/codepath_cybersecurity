#include <iostream>
#include <vector>
#include <math.h>
#include <algorithm>
using namespace std;

int main()
{
	int n, speed;
	cin >> n >> speed;

	vector<int> parts;
	vector<pair<int,int>> divBases;

	for (int i = 0; i < n; i++)
	{
		int base;
		cin >> base;
		divBases.push_back(make_pair(ceil((float)speed / (float)base), base));

	}

	for (int i = 0; i < n; i++)
	{
		int s;
		cin >> s;
		parts.push_back(s);
	}

	sort(parts.begin(), parts.end());
	sort(divBases.begin(), divBases.end());

	int pP = 0;
	int pN = 0;

	while (pN < n & pP < n)
	{
		while(pP < n && parts[pP] < divBases[pN].first) pP++;
		if (pP < n)
		{
			if (parts[pP] >= divBases[pN].first) 
			{
				pN++;
				pP++;
			}
		}
	}
	cout << pN << endl;

	return 0;
}