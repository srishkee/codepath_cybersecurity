#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<math.h>
#include <map>
using namespace std;

int GetMin(vector<int>* v)
{
	int m = v->at(0);
	for (auto p = v->begin(); p != v->end(); p++)
	{
		if (*p < m) m = *p;
	}
	return m;
}

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	map<int, vector<int>*> MAP;
	MAP[0] = new vector<int>(3, 0);
	int p, t;
	cin >> p >> t;

	for (int i = 1; i <= p; i++)
	{
		MAP[i] = new vector<int>(3, 0);
	}

	for (int i = 0; i < t; i++)
	{
		int tp;
		cin >> tp;
		MAP[tp] = MAP[0];
	}

	int a, b, c;
	for (int i = 1; i <= p; i++)
	{
		cin >> a >> b >> c;
		MAP[i]->at(0) += a;
		MAP[i]->at(1) += b;
		MAP[i]->at(2) += c;
	}

	int count = 0;
	for (int i = 1; i <= p; i++)
	{
		count += GetMin(MAP[i]);
		for (int j = 0; j < 3; j++)
		{
			MAP[i]->at(j) = 0;
		}
	}
	
	cout << count << endl;
	cout.flush(); 

	return 0;
}