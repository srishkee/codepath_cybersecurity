#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<map>
#include<set>
#include<math.h>
using namespace std;

int main(int argc, char const *argv[])
{

	ios::sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	long long int n = 0;
	cin >> n;

	vector<set<pair<int, int> > > factors(10);
	factors[0].insert({ 0,2 });
	factors[0].insert({ 0,3 });
	factors[0].insert({ 0,5 });
	factors[0].insert({ 0,7 });

	factors[1].insert({ 1,2 });
	factors[1].insert({ 0,3 });
	factors[1].insert({ 0,5 });
	factors[1].insert({ 0,7 });

	factors[2].insert({ 0,2 });
	factors[2].insert({ 1,3 });
	factors[2].insert({ 0,5 });
	factors[2].insert({ 0,7 });

	factors[3].insert({ 2,2 });
	factors[3].insert({ 0,3 });
	factors[3].insert({ 0,5 });
	factors[3].insert({ 0,7 });

	factors[4].insert({ 0,2 });
	factors[4].insert({ 0,3 });
	factors[4].insert({ 1,5 });
	factors[4].insert({ 0,7 });

	factors[5].insert({ 1,2 });
	factors[5].insert({ 1,3 });
	factors[5].insert({ 0,5 });
	factors[5].insert({ 0,7 });

	factors[6].insert({ 0,2 });
	factors[6].insert({ 0,3 });
	factors[6].insert({ 0,5 });
	factors[6].insert({ 1,7 });

	factors[7].insert({ 3,2 });
	factors[7].insert({ 0,3 });
	factors[7].insert({ 0,5 });
	factors[7].insert({ 0,7 });

	factors[8].insert({ 0,2 });
	factors[8].insert({ 2,3 });
	factors[8].insert({ 0,5 });
	factors[8].insert({ 0,7 });

	factors[9].insert({ 1,2 });
	factors[9].insert({ 0,3 });
	factors[9].insert({ 1,5 });
	factors[9].insert({ 0,7 });

	map<int, int> output;
	long long int sum = 1;
	long long int myMax = -1;
	for (long long int i = 0; i < n; ++i)
	{
		long long int num = 0;
		cin >> num;

		set<pair<int, int> >::iterator it;
		for (it = factors[num-1].begin(); it != factors[num-1].end(); ++it) {
			if (output[it->second] < it->first) {
				output[it->second] = it->first;
			}
		}
	}

	map<int, int>::iterator it;
	long int LCM = 1;
	for (it = output.begin(); it != output.end(); ++it) {
		LCM *= (long int)pow(it->first,it->second);
	}

	cout << LCM << endl;

	cout.flush();

	return 0;
}