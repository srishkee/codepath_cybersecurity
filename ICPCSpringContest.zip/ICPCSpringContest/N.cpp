#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<map>
#include<set>
#include<math.h>
using namespace std;

int main(int argc, char const *argv[])
{

	ios::sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	int n;
	cin >> n;

	map<string, int> fuel;
	fuel["uranium"] = 19;
	fuel["plutonium"] = 20;
	fuel["thorium"] = 12;


	int score = 0;
	for (int i = 0; i < n; ++i) {
		string a;
		cin >> a;
		score += fuel[a];
	}

	cout << score << endl;
	cout.flush();

	return 0;
}