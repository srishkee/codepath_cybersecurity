#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<math.h>
using namespace std;

int main(int argc, char const *argv[])
{
	int n = 0;
	cin >> n;

	int sum = 0;
	for (int i = 0; i < n; ++i)
	{
		int num = 0;
		cin >> num;
		sum += num;
	}

	cout << "Hello " << sum << " worlds" << endl;

	return 0;
}