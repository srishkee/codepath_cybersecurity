#include<iostream>
#include<queue>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<set>
#include<math.h>
using namespace std;

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);


	int letter_size;
	int point_size;

	cin >> letter_size >> point_size;

	string input;
	cin >> input;

	//map<string, int> rules;
	long int point = 0;

	for (int i = 0; i < point_size; ++i) {
		string a;
		int num;

		cin >> a >> num;

		if (a.size() > input.size()) {
			continue;
		}

		for (int j = 0; j <= input.size() - a.size(); ++j) {
			if (input.substr(j, a.size()) == a) {
				point += num;
			}
		}
	}

	cout << point << endl;
	cout.flush();

	return 0;
}