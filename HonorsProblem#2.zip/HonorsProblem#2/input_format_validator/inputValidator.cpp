#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <cmath>
#include <math.h>
#include <set>
#include <map>
using namespace std;

// Note: Visual Studio elements:
// 1. _ASSERT is the Visual Studio format for assert statements 
// 2. system("pause");

int main(int argc, char const *argv[])
{
	
	for (int fileNumber = 1; fileNumber <= 11; fileNumber++)
	{
		string fileName = to_string(fileNumber) + ".in";
		ifstream inFile(fileName);
		if (inFile.is_open())
		{
			for (int inputSection = 0; inputSection < 2; inputSection++)
			{
				// Check # of Dictionary/Search words 
				int N = 0;
				inFile >> N;
				_ASSERT(N > 0 && N <= 1000);

				// Remove extra whitespace 
				string line = "";
				getline(inFile, line);

				vector<string> arrPunc = { " ", "||", "| |", "~", "(", ")", "{", "}", "\\", ":", "; ", "\"", ",", "<", ".", ">", "?", "/" };
				vector<string> arrNum = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

				// Check remaining input lines 
				for (int i = 0; i < N; i++)
				{
					getline(inFile, line);
					// Check Size 
					_ASSERT(line.size() > 0 && line.size() <= 15); // 15 characters 
					// Check for no Punctuation 
					for (int i = 0; i < arrPunc.size(); i++) _ASSERT(line.find(arrPunc.at(i)) == string::npos);
					// Check for no Numerals
					for (int i = 0; i < arrNum.size(); i++) _ASSERT(line.find(arrNum.at(i)) == string::npos);
					// Check to ensure all lowercase letters 
					for (int i = 0; i < line.size(); i++)
					{
						char c = line.at(i); 
						int asciiVal = (int)c; 
						_ASSERT(asciiVal >= 97 && asciiVal <= 122);
					}
					int zz = 0;
				}
			}
		}
		else cout << "Error: Could not open file!" << endl;
	}

	system("pause");

	return 0;
}