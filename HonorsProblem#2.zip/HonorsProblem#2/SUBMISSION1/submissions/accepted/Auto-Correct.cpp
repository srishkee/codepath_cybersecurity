#include <iostream>
#include <string>
#include <vector>
using namespace std;

struct Node
{
	Node() : isLeafNode(false), children(26, NULL), childrenNum(0), val(' ') {};
	char val; // Character value of node (for debugging purposes)
	bool isLeafNode; // Marks end of word
	int childrenNum; // Marks number of children Node has 
	vector<Node*> children; // Vector of Node's children 
};

// Inserts a word into Trie 
void insert(Node* root, string str)
{
	Node* curr = root;
	for (int i = 0; i < str.size(); ++i) // Insert all string characters
	{
		int idx = str.at(i) - 'a';
		if (curr->children[idx] == NULL) // If character not in trie already
		{
			Node* n = new Node; // Create new node
			n->val = (char)(idx + 97); // Set corresponding letter (for debugging) 
			curr->children[idx] = n; // Assign new node to position  
		}
		curr->childrenNum++; // Increment number of children 
		curr = curr->children[idx]; // Advance pointer
	}
	curr->isLeafNode = true; // Mark end of word
}

// Search for a word in Trie 
int search(Node* root, string str)
{
	Node* curr = root;
	int ctr = -1; 
	for (int i = 0; i < str.size(); ++i) // Iterate over string
	{
		int idx = str.at(i) - 'a'; // Find index 
		if (curr->isLeafNode) { // If dictionary word is substring of email word 
			return (str.size() - i + 2);
		}
		if (!curr->children[idx]) break; // If word does not exist within dictionary - break! 
		if (curr->childrenNum > 1) ctr = (ctr == -1) ? 1 : ctr + 1; // If multiple similar words, have to keep typing extra characters! 
		curr = curr->children[idx]; // Explore next level of Trie 
	} 
	// If reached end of dictionary word return ctr! 
	// Else word is nested in dictionary (must type every character) 
	return (curr->isLeafNode) ? ctr : str.size(); 
}

int main(int argc, char const *argv[])
{
	// 1. Insert all Dictionary words in Trie 
	int N = 0;
	cin >> N;
	Node* root = new Node;
	for (int j = 0; j < N; j++)
	{
		string dictWord = "";
		cin >> dictWord;
		insert(root, dictWord);
	}
	
	// 2. Search Trie for each word in email 
	int M = 0;
	cin >> M;
	vector<int> res; 
	for (int i = 0; i < M; i++)
	{
		string word = "";
		cin >> word; 
		int ans = search(root, word);
		if (ans == -1) res.push_back(word.size());
		else res.push_back(search(root, word));
	}

	// 3. Print results 
	for (int i = 0; i < res.size(); i++)
	{
		cout << res.at(i) << endl;
	}

	return 0;
}