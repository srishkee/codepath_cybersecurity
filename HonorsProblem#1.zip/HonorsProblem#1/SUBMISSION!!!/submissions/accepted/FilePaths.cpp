#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
#include <string>
#include <cmath>
#include <math.h>
#include <set>
#include <map>
using namespace std;

// Print Solution Output 
void printOutput(std::vector<std::vector<string>> v)
{
	for (int i = 0; i < v.size(); ++i)
	{
		string s = "";
		for (int j = 0; j < v.at(i).size(); ++j)
		{
			s += (v.at(i).at(j) + "|");
		}
		s.pop_back(); // Remove last delimiter character ("|")
		cout << s << endl; // Print output 
	}
}

// Tokenizes string based on delimiting character ("|")
std::vector<string> parseFilePath(string s)
{
	string delimiter = "|", token = "";
	vector<string> v; // Vector of tokenized strings 
	int pos = 0;
	while ((pos = s.find(delimiter)) != std::string::npos) // While delimiter exists in string 
	{
		token = s.substr(0, pos); // Get token
		v.push_back(token); // Add token to vector 
		s.erase(0, pos + delimiter.length()); // Remove token from original string 
	}
	token = s.substr(0, s.size()); // Get last token 
	v.push_back(token); // Add last token to vector 

	return v; // Return vector of tokenized strings 
}

// Checks if newStr is parent of oldStr 
bool isParent(vector<string> oldStr, vector<string> newStr)
{
	int j = 0;
	while (j < oldStr.size() && j < newStr.size())
	{
		if (oldStr.at(j) != newStr.at(j)) return 0; // Conflict
		else if (j == newStr.size() - 1) return 1; // If end of newStr 
		j++;
	}
}

// Solves the problem 
void solveProblem(vector<string> myFile, std::vector<std::vector<string>> &filePathsList)
{
	for (int i = 0; i < filePathsList.size(); i++) // Iterate over all stored file path strings 
	{
		int j = 0;
		while (j < myFile.size() && j < filePathsList.at(i).size()) // Iterate through both strings 
		{
			if (myFile.at(j) != filePathsList.at(i).at(j)) break; // Conflict 
			else if (j == filePathsList.at(i).size() - 1) return; // s1 = parent!
			else if (j == myFile.size() - 1) // s2 = parent!
			{
				for (int k = 0; k < filePathsList.size(); k++)
				{
					// If myFile is parent of string, then erase string (all occurences are replaced with myFile)
					if (isParent(filePathsList.at(k), myFile)) filePathsList.erase(filePathsList.begin()+k);
				}
				break;
			} 
			j++;
		}
	}
	filePathsList.push_back(myFile); // If no parent/child match, add file path 
}

int main(int argc, char const *argv[])
{
	// Number of test cases 
	int n = 0;
	cin >> n;

	// 2D vector of File Paths
	std::vector<std::vector<string>> filePathsList;
	for (int i = 0; i < n; ++i)
	{
		string s = "";
		cin >> s;
		vector<string> myFile = parseFilePath(s); // Parse File Path 
		if(filePathsList.size() == 0) filePathsList.push_back(myFile); // Add 1st file to 2D vector 

		else solveProblem(myFile, filePathsList); // Else solve problem 

	}

	// cout << endl; // (REMOVE!!! Extra space to distinguish output during testing)

	printOutput(filePathsList);



		return 0;
}