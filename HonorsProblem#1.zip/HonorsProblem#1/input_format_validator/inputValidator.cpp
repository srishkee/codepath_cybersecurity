#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <cmath>
#include <math.h>
#include <set>
#include <map>
using namespace std;

// Note: _ASSERT is the Visual Studio format for assert statements 

int main(int argc, char const *argv[])
{
	ifstream inFile("input.txt");
	if (inFile.is_open())
	{
		// Check # of test cases
		int n = 0;
		inFile >> n;
		_ASSERT(n > 0 && n < 1000);

		// Remove extra whitespace 
		string line = "";
		getline(inFile, line); 

		vector<string> arrPunc = { " ", "||", "| |", "~", "(", ")", "{", "}", "\\", ":", "; ", "\"", ",", "<", ".", ">", "?", "/" };
		vector<string> arrNum = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" }; 

		// Check remaining input lines 
		while (getline(inFile, line))
		{
			// Check Size 
			_ASSERT(line.size() > 0 && line.size() < 20); // 10 characters + 9 "|" characters 
			// Check Punctuation 
			for (int i = 0; i < arrPunc.size(); i++) _ASSERT(line.find(arrPunc.at(i)) == string::npos);
			// Check Numerals
			for (int i = 0; i < arrNum.size(); i++) _ASSERT(line.find(arrNum.at(i)) == string::npos);
		}
	}
	else cout << "Error: Could not open file!" << endl;

	system("pause");

	return 0;
}